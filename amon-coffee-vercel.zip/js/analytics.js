/* =========================================================
   القياس والخصوصية – Google Analytics 4
   >>> حط رقم القياس بتاعك هنا (يبدأ بـ G-) <<<
   التحميل بيحصل بس بعد موافقة الزائر على ملفات تعريف الارتباط.
   ========================================================= */
const GA_MEASUREMENT_ID = "G-XXXXXXXXXX";
const SITE_URL = "https://amon-coffee.vercel.app";
const CONSENT_KEY = "amon-consent";

window.dataLayer = window.dataLayer || [];
window.gtag = window.gtag || function () { window.dataLayer.push(arguments); };
gtag("js", new Date());

function loadGA() {
  if (loadGA.done || !GA_MEASUREMENT_ID || GA_MEASUREMENT_ID.includes("XXXX")) return;
  loadGA.done = true;
  const s = document.createElement("script");
  s.async = true;
  s.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
  document.head.appendChild(s);
  gtag("config", GA_MEASUREMENT_ID, { anonymize_ip: true });
}

/* استخدمها في أي مكان: track("add_to_cart", { value: 230 }) */
function track(name, params = {}) {
  try { gtag("event", name, params); } catch { /* القياس اختياري */ }
}

document.addEventListener("DOMContentLoaded", () => {
  const choice = (() => { try { return localStorage.getItem(CONSENT_KEY); } catch { return null; } })();
  if (choice === "accepted") loadGA();

  const box = document.getElementById("consent");
  if (!box || choice) return;
  box.hidden = false;
  const save = value => {
    try { localStorage.setItem(CONSENT_KEY, value); } catch { /* التخزين غير متاح */ }
    box.hidden = true;
    if (value === "accepted") loadGA();
  };
  document.getElementById("consentAccept").onclick = () => save("accepted");
  document.getElementById("consentDecline").onclick = () => save("declined");
});
