/* =========================================================
   أمون – منطق الموقع
   ========================================================= */

/* ---------- الإعدادات ---------- */
const CONTACT = { display: "+20 11 11859452", intl: "201111859452" };
const WHATSAPP_NUMBER = CONTACT.intl; // رقم استقبال الطلبات على واتساب
// >>> غيّر دول لبياناتك الحقيقية قبل النشر <<<
const PAYMENT = {
  instapay: "01158399885",
  wallet: "01111859452", // كاش / محفظة
  depositRate: 0.30
};

const SIZES = [
  { grams: 250,  label: "250 جرام" },
  { grams: 500,  label: "500 جرام" },
  { grams: 1000, label: "1 كيلو" }
];
const CURRENCY = "ج.م";
const SHIPPING_FEE = 70; // توصيل القاهرة والجيزة
const CART_KEY = "amon-cart";
const DATA_URL = "data/products.json";
const MAX_QTY = 20;

/* نسخة احتياطية لو ملف data/products.json مش متاح (مثلاً لو فتحت الصفحة من غير سيرفر) */
const DEFAULT_DATA = {
  "products": [
    {
      "id": "light-plain",
      "name": "فاتح ساده",
      "image": "assets/products/light-plain.png",
      "desc": "تحميص فاتح بنكهة نقية وخفيفة.",
      "roast": "light",
      "style": "plain",
      "prices": {
        "250": 230,
        "500": 450,
        "1000": 840
      },
      "stock": {
        "250": 50,
        "500": 50,
        "1000": 50
      }
    },
    {
      "id": "medium-plain",
      "name": "وسط ساده",
      "image": "assets/products/medium-plain.png",
      "desc": "تحميص متوازن بطعم غني ومتزن.",
      "roast": "medium",
      "style": "plain",
      "prices": {
        "250": 230,
        "500": 450,
        "1000": 840
      },
      "stock": {
        "250": 50,
        "500": 50,
        "1000": 50
      }
    },
    {
      "id": "dark-plain",
      "name": "غامق ساده",
      "image": "assets/products/dark-plain.png",
      "desc": "تحميص غامق بقوام قوي وطعم عميق.",
      "roast": "dark",
      "style": "plain",
      "prices": {
        "250": 230,
        "500": 450,
        "1000": 840
      },
      "stock": {
        "250": 50,
        "500": 50,
        "1000": 50
      }
    },
    {
      "id": "light-spiced",
      "name": "فاتح محوج",
      "image": "assets/products/light-spiced.png",
      "desc": "فاتح مع لمسة من التوابل الشرقية.",
      "roast": "light",
      "style": "spiced",
      "prices": {
        "250": 250,
        "500": 500,
        "1000": 920
      },
      "stock": {
        "250": 50,
        "500": 50,
        "1000": 50
      }
    },
    {
      "id": "medium-spiced",
      "name": "وسط محوج",
      "image": "assets/products/medium-spiced.png",
      "desc": "وسط محوج بتوازن بين الدفء والنكهة.",
      "roast": "medium",
      "style": "spiced",
      "prices": {
        "250": 250,
        "500": 500,
        "1000": 920
      },
      "stock": {
        "250": 50,
        "500": 50,
        "1000": 50
      }
    },
    {
      "id": "dark-spiced",
      "name": "غامق محوج",
      "image": "assets/products/dark-spiced.png",
      "desc": "غامق محوج بنكهة جريئة وأصيلة.",
      "roast": "dark",
      "style": "spiced",
      "prices": {
        "250": 250,
        "500": 500,
        "1000": 920
      },
      "stock": {
        "250": 50,
        "500": 50,
        "1000": 50
      }
    },
    {
      "id": "special-yemeni",
      "name": "اسبشيال أمون بالمزيج اليمني",
      "image": "assets/products/special-yemeni.png",
      "desc": "مزيج يمني خاص من إنتاج أمون.",
      "roast": "special",
      "style": "special",
      "prices": {
        "250": 350,
        "500": 700,
        "1000": 1300
      },
      "stock": {
        "250": 50,
        "500": 50,
        "1000": 50
      }
    },
    {
      "id": "fayagra",
      "name": "فياجرة أمون",
      "image": "assets/products/fayagra.png",
      "desc": "تركيبة أمون المميزة.",
      "roast": "special",
      "style": "special",
      "prices": {
        "250": 400,
        "500": 800,
        "1000": 1500
      },
      "stock": {
        "250": 50,
        "500": 50,
        "1000": 50
      }
    }
  ],
  "offers": [
    {
      "id": "amon-offer",
      "name": "عروض أمون",
      "desc": "٤ أكياس × ٢٥٠ جرام بسعر مميز",
      "active": true,
      "items": [
        {
          "productId": "special-yemeni",
          "size": 250
        },
        {
          "productId": "fayagra",
          "size": 250
        },
        {
          "productId": "medium-plain",
          "size": 250
        },
        {
          "productId": "dark-spiced",
          "size": 250
        }
      ],
      "price": 1000
    }
  ],
  "discount": {
    "threshold": 2500,
    "rate": 0.1
  }
};

let PRODUCTS = [];
let OFFERS = [];
let DISCOUNT = { threshold: 2500, rate: 0.10 };
let cart = [];

const FILTERS = [
  { id: "all",     label: "الكل", test: () => true },
  { id: "light",   label: "فاتح", test: p => p.roast === "light" },
  { id: "medium",  label: "وسط",  test: p => p.roast === "medium" },
  { id: "dark",    label: "غامق", test: p => p.roast === "dark" },
  { id: "spiced",  label: "محوج", test: p => p.style === "spiced" },
  { id: "special", label: "مميز", test: p => p.style === "special" }
];
let activeFilter = "all";
let searchQuery = "";
const normalizeAr = t => (t || "").trim().toLowerCase().replace(/[إأآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي");

/* ---------- أدوات مساعدة ---------- */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const fmt = n => `${Number(n).toLocaleString("en-US")} ${CURRENCY}`;
const sizeLabel = g => SIZES.find(s => s.grams === g)?.label ?? `${g} جرام`;
const findProduct = id => PRODUCTS.find(p => p.id === id);
const findOffer = id => OFFERS.find(o => o.id === id);
const priceOf = (p, g) => Number(p?.prices?.[g]) || 0;
const stockOf = (p, g) => Math.max(0, Math.floor(Number(p?.stock?.[g]) || 0));
const isAvailable = (p, g) => !!p && priceOf(p, g) > 0 && stockOf(p, g) > 0;
const maxQtyFor = (p, g) => Math.min(MAX_QTY, stockOf(p, g));

function offerAvailable(o) {
  return !!o && o.active && o.items.length > 0 &&
    o.items.every(c => isAvailable(findProduct(c.productId), c.size));
}
function offerOriginal(o) {
  return o.items.reduce((s, c) => s + priceOf(findProduct(c.productId), c.size), 0);
}

function showToast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => t.classList.remove("show"), 2400);
}

function productImg(p, cls) {
  return `<div class="${cls}">
    <div class="img-placeholder">صورة ${p.name}</div>
    <img src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.remove()">
  </div>`;
}

/* ---------- تحميل البيانات ---------- */
function normalizeProduct(p) {
  return {
    ...p,
    desc: p.desc || "",
    image: p.image || `assets/products/${p.id}.png`,
    roast: p.roast || "light",
    style: p.style || "plain",
    prices: Object.fromEntries(SIZES.map(s => [s.grams, Number(p.prices?.[s.grams]) || 0])),
    stock: Object.fromEntries(SIZES.map(s => [s.grams, Math.max(0, Math.floor(Number(p.stock?.[s.grams]) || 0))]))
  };
}

async function loadData() {
  let data = DEFAULT_DATA;
  try {
    const res = await fetch(DATA_URL, { cache: "no-store" });
    if (!res.ok) throw new Error("not ok");
    data = await res.json();
  } catch { /* نستخدم النسخة الاحتياطية */ }

  PRODUCTS = (data.products || []).map(normalizeProduct);
  OFFERS = (data.offers || []).map(o => ({
    ...o,
    active: o.active !== false,
    price: Number(o.price) || 0,
    image: o.image || "",
    items: (o.items || []).filter(c => findProduct(c.productId))
  }));
  if (data.discount) DISCOUNT = { threshold: Number(data.discount.threshold) || 0, rate: Number(data.discount.rate) || 0 };
}

/* ---------- الأنيميشن والظهور عند السكرول ---------- */
const revealIO = "IntersectionObserver" in window
  ? new IntersectionObserver(entries => entries.forEach(en => {
      if (!en.isIntersecting) return;
      const el = en.target;
      el.classList.add("in");
      revealIO.unobserve(el);
      setTimeout(() => { el.style.transitionDelay = ""; }, 1000);
    }), { threshold: 0.12 })
  : null;

function observeReveal() {
  $$(".reveal:not(.in)").forEach(el => {
    if (revealIO) revealIO.observe(el);
    else el.classList.add("in");
  });
}

/* =========================================================
   1) العروض
   ========================================================= */
function renderOffers() {
  const section = $("#offers");
  if (!OFFERS.length) { section.hidden = true; return; }
  section.hidden = false;
  $("#discountHint").textContent = `خصم ${Math.round(DISCOUNT.rate * 100)}% على أي طلب أكبر من ${fmt(DISCOUNT.threshold)}`;
  $("#offerGrid").innerHTML = OFFERS.map((o, i) => {
    const avail = offerAvailable(o);
    const original = offerOriginal(o);
    const save = Math.max(0, original - o.price);
    return `
      <article class="offer-card reveal" style="transition-delay:${i * 90}ms">
        <span class="offer-badge">عرض</span>
        <h3>${o.name}</h3>
        <p class="offer-desc">${o.desc || ""}</p>
        <ul class="offer-items">
          ${o.items.map(c => {
            const p = findProduct(c.productId);
            return `<li>${p.name} – ${sizeLabel(c.size)}</li>`;
          }).join("")}
        </ul>
        <div class="offer-price">
          ${save ? `<span class="old">${fmt(original)}</span>` : ""}
          <b>${fmt(o.price)}</b>
        </div>
        ${save ? `<div class="offer-save">وفّر ${fmt(save)}</div>` : ""}
        <button class="btn-gold" data-offer="${o.id}" ${avail ? "" : "disabled"}>
          ${avail ? "أضف العرض للسلة" : "غير متاح حالياً"}
        </button>
      </article>`;
  }).join("");
  observeReveal();
}

$("#offerGrid").addEventListener("click", e => {
  const b = e.target.closest("[data-offer]");
  if (!b || b.disabled) return;
  const res = addToCart({ offerId: b.dataset.offer, qty: 1 });
  if (res.ok) showToast("تمت إضافة العرض إلى السلة");
  else showToast(res.msg);
});

/* =========================================================
   2) الفلاتر والمنتجات
   ========================================================= */
function renderFilters() {
  $("#filters").innerHTML = FILTERS.map(f =>
    `<button class="chip" data-filter="${f.id}" aria-pressed="${f.id === activeFilter}">${f.label}</button>`
  ).join("");
}

function renderProducts() {
  const test = FILTERS.find(f => f.id === activeFilter).test;
  const q = normalizeAr(searchQuery);
  const list = PRODUCTS.filter(test).filter(p => !q || normalizeAr(p.name).includes(q) || normalizeAr(p.desc).includes(q));
  $("#productGrid").innerHTML = list.map((p, i) => {
    const anyAvailable = SIZES.some(s => isAvailable(p, s.grams));
    const from = priceOf(p, 250) || Math.min(...SIZES.map(s => priceOf(p, s.grams)).filter(Boolean));
    return `
      <article class="card reveal" style="transition-delay:${i * 70}ms">
        ${productImg(p, "card-img")}
        <div class="card-body">
          <h3>${p.name}</h3>
          <div class="from">${anyAvailable ? `يبدأ من <b>${fmt(from)}</b>` : `<span class="soldout">نفد المخزون حالياً</span>`}</div>
          <button class="btn-outline" data-open="${p.id}">اختار الحجم</button>
        </div>
      </article>`;
  }).join("") || `<p class="empty">${q ? "ما فيش منتج بالاسم ده" : "لا توجد منتجات في هذا التصنيف"}</p>`;
  observeReveal();
}

/* =========================================================
   3) نافذة المنتج – اختيار الحجم والسعر
   ========================================================= */
const pv = { product: null, size: null, qty: 1 };

function openProduct(id) {
  const p = findProduct(id);
  if (!p) return;
  pv.product = p;
  pv.size = null;
  pv.qty = 1;

  $("#pvTitle").textContent = p.name;
  $("#pvDesc").textContent = p.desc || "";
  const img = $("#pvImg");
  img.onerror = () => { img.style.display = "none"; };
  img.style.display = "";
  img.src = p.image;
  img.alt = p.name;

  $("#pvSizes").innerHTML = SIZES.map(s => {
    const ok = isAvailable(p, s.grams);
    return `<button class="size-btn" data-size="${s.grams}" aria-pressed="false" ${ok ? "" : "disabled"}>
      ${s.label}${ok ? "" : `<small>نفد</small>`}
    </button>`;
  }).join("");

  $("#pvError").textContent = "";
  // صور المنتج المصغرة: الأمامية والخلفية
  const gallery = p.gallery || [p.image, "assets/products/bag-back.png"];
  $("#pvThumbs").innerHTML = gallery.map((src, i) =>
    `<button type="button" class="pv-thumb ${i === 0 ? "on" : ""}" data-src="${src}" aria-label="صورة ${i + 1}"><img src="${src}" alt=""></button>`
  ).join("");
  // التقييمات: بتظهر بس لو المنتج فيه تقييم حقيقي في products.json
  const r = p.rating;
  const rEl = $("#pvRating");
  if (r && r.score && r.count) {
    const full = Math.round(Number(r.score));
    rEl.innerHTML = `<span class="stars">${"★".repeat(full)}${"☆".repeat(5 - full)}</span> <span>${Number(r.score).toFixed(1)} (${r.count} تقييم)</span>`;
    rEl.hidden = false;
  } else {
    rEl.hidden = true;
  }
  $("#tabDesc").textContent = p.desc || "";
  $("#tabInfo").textContent = `الأحجام المتاحة: ${SIZES.map(s => s.label).join("، ")}. التوصيل للقاهرة والجيزة 70 ج.م.`;
  selectTab("tabDesc");
  renderPV();
  openOverlay("#productOverlay");
  track("view_item", { currency: "EGP", value: priceOf(p, 250), items: [{ item_id: p.id, item_name: p.name }] });
}

function renderPV(bump = false) {
  const { product: p, size } = pv;
  $$("#pvSizes .size-btn").forEach(b =>
    b.setAttribute("aria-pressed", String(Number(b.dataset.size) === size))
  );

  const max = size ? maxQtyFor(p, size) : MAX_QTY;
  if (pv.qty > max) pv.qty = Math.max(1, max);

  const priceEl = $("#pvPrice");
  if (size) {
    $("#pvSizeLabel").textContent = `الحجم المختار: ${sizeLabel(size)}`;
    priceEl.textContent = fmt(priceOf(p, size) * pv.qty);
    $("#pvNote").textContent = pv.qty > 1 ? `${fmt(priceOf(p, size))} × ${pv.qty}` : "السعر للحجم المختار";
    $("#pvStock").textContent = `المتاح: ${stockOf(p, size)}`;
    if (bump) {
      priceEl.classList.add("bump");
      setTimeout(() => priceEl.classList.remove("bump"), 200);
    }
  } else {
    $("#pvSizeLabel").textContent = "لم يتم اختيار الحجم";
    priceEl.textContent = "—";
    $("#pvNote").textContent = "اختار الحجم لعرض السعر";
    $("#pvStock").textContent = "";
  }

  $("#pvQty").textContent = pv.qty;
  $("#pvMinus").disabled = pv.qty <= 1;
  $("#pvPlus").disabled = !size || pv.qty >= max;
  $("#pvAdd").disabled = !size;
}

$("#pvSizes").addEventListener("click", e => {
  const btn = e.target.closest(".size-btn");
  if (!btn || btn.disabled) return;
  pv.size = Number(btn.dataset.size);
  $("#pvError").textContent = "";
  renderPV(true);
});
$("#pvPlus").onclick = () => { pv.qty++; renderPV(true); };
$("#pvMinus").onclick = () => { if (pv.qty > 1) { pv.qty--; renderPV(true); } };

$("#pvAdd").onclick = () => {
  if (!pv.product) return;
  if (!pv.size) {
    $("#pvError").textContent = "من فضلك اختار الحجم أولاً";
    return;
  }
  const res = addToCart({ productId: pv.product.id, size: pv.size, qty: pv.qty });
  if (!res.ok) {
    $("#pvError").textContent = res.msg;
    return;
  }
  closeOverlay("#productOverlay");
  showToast("تمت إضافة المنتج إلى السلة");
};

/* =========================================================
   4) السلة – منتجات وعروض، والمخزون محسوب على الكل
   ========================================================= */
const isOffer = item => !!item.offerId;
const keyOf = item => isOffer(item) ? `o:${item.offerId}` : `p:${item.productId}:${item.size}`;

function itemInfo(item) {
  if (isOffer(item)) {
    const o = findOffer(item.offerId);
    return {
      name: o.name,
      sizeText: o.items.map(c => `${findProduct(c.productId).name} ${sizeLabel(c.size)}`).join(" + "),
      unit: o.price
    };
  }
  const p = findProduct(item.productId);
  return { name: p.name, sizeText: sizeLabel(item.size), unit: priceOf(p, item.size), image: p.image };
}

/* كل عنصر في السلة بيحجز كمية من كل منتج/حجم بيكونه */
function componentsOf(item) {
  if (isOffer(item)) return findOffer(item.offerId).items.map(c => ({ productId: c.productId, size: c.size, n: item.qty }));
  return [{ productId: item.productId, size: item.size, n: item.qty }];
}

function shortageOf(list) {
  const need = {};
  list.forEach(it => componentsOf(it).forEach(c => {
    const k = `${c.productId}|${c.size}`;
    need[k] = (need[k] || 0) + c.n;
  }));
  for (const [k, n] of Object.entries(need)) {
    const [pid, g] = k.split("|");
    const p = findProduct(pid);
    if (!p || stockOf(p, Number(g)) < n) return { product: p, size: Number(g), available: stockOf(p, Number(g)) };
  }
  return null;
}

function loadCart() {
  try {
    const raw = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
    const list = [];
    raw.forEach(i => {
      let item = null;
      if (i.offerId) {
        if (offerAvailable(findOffer(i.offerId))) item = { offerId: i.offerId, qty: Math.max(1, Number(i.qty) || 1) };
      } else {
        const p = findProduct(i.productId);
        if (p && isAvailable(p, i.size)) item = { productId: i.productId, size: i.size, qty: Math.max(1, Number(i.qty) || 1) };
      }
      if (!item) return;
      list.push(item);
      while (item.qty > 1 && shortageOf(list)) item.qty--;
      if (shortageOf(list)) list.pop();
    });
    return list;
  } catch { return []; }
}

function saveCart() {
  try { localStorage.setItem(CART_KEY, JSON.stringify(cart)); } catch { /* التخزين غير متاح */ }
}

function addToCart(item) {
  if (isOffer(item) && !offerAvailable(findOffer(item.offerId))) return { ok: false, msg: "العرض ده غير متاح حالياً" };
  if (!isOffer(item) && !isAvailable(findProduct(item.productId), item.size)) return { ok: false, msg: "هذا الحجم غير متوفر حالياً" };

  const candidate = cart.map(i => ({ ...i }));
  const existing = candidate.find(i => keyOf(i) === keyOf(item));
  if (existing) existing.qty += item.qty;
  else candidate.push({ ...item });

  const short = shortageOf(candidate);
  if (short) {
    return { ok: false, msg: `المتاح من ${short.product.name} ${sizeLabel(short.size)} هو ${short.available} فقط` };
  }
  cart = candidate;
  persistAndRender();
  const info = itemInfo(item);
  track("add_to_cart", { currency: "EGP", value: info.unit * item.qty, items: [{
    item_id: item.offerId || item.productId, item_name: info.name,
    item_variant: info.sizeText, price: info.unit, quantity: item.qty }] });
  return { ok: true };
}

function changeQty(index, delta) {
  const item = cart[index];
  if (!item) return;
  const next = item.qty + delta;
  if (next < 1) return;
  if (next > MAX_QTY) return;
  const candidate = cart.map((i, idx) => idx === index ? { ...i, qty: next } : { ...i });
  const short = shortageOf(candidate);
  if (short) {
    showToast(`المتاح من ${short.product.name} ${sizeLabel(short.size)} هو ${short.available} فقط`);
    return;
  }
  item.qty = next;
  persistAndRender();
}

function removeItem(index) {
  const name = itemInfo(cart[index]).name;
  cart.splice(index, 1);
  persistAndRender();
  showToast(`تم حذف ${name} من السلة`);
}

const lineTotal = item => itemInfo(item).unit * item.qty;
const subtotal = () => cart.reduce((s, i) => s + lineTotal(i), 0);
const discountFor = sub => sub > DISCOUNT.threshold ? Math.round(sub * DISCOUNT.rate) : 0;
function cartTotals() {
  const sub = subtotal();
  const discount = discountFor(sub);
  const shipping = cart.length ? SHIPPING_FEE : 0;
  return { sub, discount, shipping, total: sub - discount + shipping };
}
const cartCount = () => cart.reduce((s, i) => s + i.qty, 0);

function persistAndRender() {
  saveCart();
  renderCart();
}

function renderCart() {
  const count = cartCount();
  const badge = $("#cartBadge");
  badge.hidden = count === 0;
  badge.textContent = count;
  badge.classList.remove("bump");
  void badge.offsetWidth;
  badge.classList.add("bump");

  const body = $("#cartBody");
  const foot = $("#cartFoot");

  if (cart.length === 0) {
    body.innerHTML = `<div class="empty"><div class="big">☕</div><p>سلة المشتريات فارغة</p></div>`;
    foot.innerHTML = `<button class="btn-outline" data-close-drawer>تابع التسوق</button>`;
    return;
  }

  body.innerHTML = cart.map((item, i) => {
    const info = itemInfo(item);
    const canMore = !shortageOf(cart.map((x, idx) => idx === i ? { ...x, qty: x.qty + 1 } : x)) && item.qty < MAX_QTY;
    return `
      <div class="cart-item ${isOffer(item) ? "is-offer" : ""}">
        <div class="cart-thumb">
          ${info.image ? `<img src="${info.image}" alt="${info.name}" onerror="this.style.display='none'">` : `<span class="offer-thumb">عرض</span>`}
        </div>
        <div>
          <div class="ci-name">${info.name}</div>
          <div class="ci-meta">${info.sizeText}</div>
          <div class="ci-meta">${fmt(info.unit)}</div>
          <div class="ci-line">${fmt(lineTotal(item))}</div>
          <button class="remove" data-remove="${i}">حذف</button>
        </div>
        <div class="ci-actions">
          <div class="stepper">
            <button data-qty="${i}" data-delta="1" ${canMore ? "" : "disabled"} aria-label="زيادة">+</button>
            <span>${item.qty}</span>
            <button data-qty="${i}" data-delta="-1" ${item.qty <= 1 ? "disabled" : ""} aria-label="تقليل">−</button>
          </div>
        </div>
      </div>`;
  }).join("");

  const t = cartTotals();
  foot.innerHTML = `
    <div class="totals"><span>عدد القطع</span><span>${count}</span></div>
    <div class="totals"><span>المجموع الفرعي</span><span>${fmt(t.sub)}</span></div>
    ${t.discount ? `<div class="totals discount"><span>خصم ${Math.round(DISCOUNT.rate * 100)}%</span><span>- ${fmt(t.discount)}</span></div>` : ""}
    <div class="totals"><span>الشحن (القاهرة والجيزة)</span><span>${fmt(t.shipping)}</span></div>
    <div class="totals grand"><span>إجمالي الطلب</span><span>${fmt(t.total)}</span></div>
    <button class="btn-gold" id="checkoutBtn">إتمام الطلب</button>
    <button class="btn-outline" data-close-drawer>تابع التسوق</button>`;
}

$("#cartBody").addEventListener("click", e => {
  const q = e.target.closest("[data-qty]");
  if (q) return changeQty(Number(q.dataset.qty), Number(q.dataset.delta));
  const r = e.target.closest("[data-remove]");
  if (r) removeItem(Number(r.dataset.remove));
});

/* =========================================================
   5) إتمام الطلب – العربون 30% + الباقي عند الاستلام
   ========================================================= */
const PHONE_RE = /^01[0-9]{9}$/;

/* بيانات المنتجات المنظمة (Schema.org) عشان محركات البحث وAI يفهموا الأسعار */
function injectProductSchema() {
  const items = PRODUCTS.map(p => {
    const prices = SIZES.map(s => priceOf(p, s.grams)).filter(Boolean);
    if (!prices.length) return null;
    return {
      "@type": "Product",
      name: p.name,
      description: p.desc,
      image: `${SITE_URL}/${p.image}`,
      brand: { "@type": "Brand", name: "أمون" },
      offers: {
        "@type": "AggregateOffer",
        priceCurrency: "EGP",
        lowPrice: Math.min(...prices),
        highPrice: Math.max(...prices),
        offerCount: prices.length,
        availability: "https://schema.org/InStock",
        seller: { "@type": "Organization", name: "أمون" }
      }
    };
  }).filter(Boolean);

  const script = document.createElement("script");
  script.type = "application/ld+json";
  script.textContent = JSON.stringify({
    "@context": "https://schema.org",
    "@graph": [{
      "@type": "ItemList",
      name: "منتجات أمون",
      itemListElement: items.map((item, i) => ({ "@type": "ListItem", position: i + 1, item }))
    }]
  });
  document.head.appendChild(script);
}

function paymentSplit() {
  const { sub, discount, shipping, total } = cartTotals();
  const deposit = Math.round(total * PAYMENT.depositRate);
  return { sub, discount, shipping, total, deposit, remaining: total - deposit };
}

function selectedPayMethod() {
  return document.querySelector('input[name="payMethod"]:checked')?.value || "instapay";
}

function renderPayment() {
  const s = paymentSplit();
  const target = selectedPayMethod() === "instapay"
    ? `إنستاباي: <b>${PAYMENT.instapay}</b>`
    : `المحفظة: <b>${PAYMENT.wallet}</b>`;
  $("#payDetails").innerHTML = `حوّل العربون (${fmt(s.deposit)}) على ${target}`;
  $("#paySplit").innerHTML =
    `<div>العربون الآن (30%)<b>${fmt(s.deposit)}</b></div>` +
    `<div>يُدفع عند الاستلام<b>${fmt(s.remaining)}</b></div>`;
}

function openCheckout() {
  if (cart.length === 0) return;
  const short = shortageOf(cart);
  if (short) {
    showToast(`المتاح من ${short.product.name} ${sizeLabel(short.size)} هو ${short.available} فقط، عدّل السلة`);
    return;
  }
  closeCart();
  $("#checkoutForm").hidden = false;
  $("#resultPanel").hidden = true;
  const s = paymentSplit();
  $("#coSummary").innerHTML =
    cart.map(i => {
      const info = itemInfo(i);
      return `<div><span>${info.name} (${info.sizeText}) × ${i.qty}</span><span>${fmt(lineTotal(i))}</span></div>`;
    }).join("") +
    `<div><span>المجموع الفرعي</span><span>${fmt(s.sub)}</span></div>` +
    (s.discount ? `<div><span>خصم ${Math.round(DISCOUNT.rate * 100)}%</span><span>- ${fmt(s.discount)}</span></div>` : "") +
    `<div><span>الشحن (القاهرة والجيزة)</span><span>${fmt(s.shipping)}</span></div>` +
    `<div class="tot"><span>إجمالي الطلب</span><span>${fmt(s.total)}</span></div>`;
  renderPayment();
  track("begin_checkout", { currency: "EGP", value: s.total, items: cart.map(i => ({
    item_id: i.offerId || i.productId, item_name: itemInfo(i).name, quantity: i.qty, price: itemInfo(i).unit })) });
  openOverlay("#checkoutOverlay");
}

function validateCheckout(form) {
  const values = {
    name: form.elements.name.value.trim(),
    phone: form.elements.phone.value.trim().replace(/\s|-/g, ""),
    address: form.elements.address.value.trim(),
    txnRef: form.elements.txnRef.value.trim()
  };
  const errors = {};
  if (values.name.length < 3) errors.name = "من فضلك اكتب اسمك الكامل";
  if (!PHONE_RE.test(values.phone)) errors.phone = "اكتب رقم موبايل مصري صحيح (11 رقم يبدأ بـ 01)";
  if (values.address.length < 8) errors.address = "من فضلك اكتب العنوان بالتفصيل";
  if (values.txnRef.length < 4) errors.txnRef = "اكتب رقم العملية أو رقم المحفظة للتأكيد";

  $$("[data-field]", form).forEach(f => {
    const key = f.dataset.field;
    f.classList.toggle("invalid", !!errors[key]);
    f.querySelector(".err").textContent = errors[key] || "";
  });
  return { ok: Object.keys(errors).length === 0, values };
}

$("#checkoutForm").addEventListener("change", e => {
  if (e.target.name === "payMethod") renderPayment();
});

$("#checkoutForm").addEventListener("submit", e => {
  e.preventDefault();
  const form = e.currentTarget;
  const { ok, values } = validateCheckout(form);
  if (!ok) return;

  const s = paymentSplit();
  const lines = cart.map(i => {
    const info = itemInfo(i);
    return `- ${info.name} (${info.sizeText}) | ${i.qty} × ${fmt(info.unit)} = ${fmt(lineTotal(i))}`;
  });
  const text = [
    "طلب جديد من موقع أمون",
    "",
    `الاسم: ${values.name}`,
    `الموبايل: ${values.phone}`,
    `العنوان: ${values.address}`,
    "",
    "المنتجات:",
    ...lines,
    "",
    `المجموع الفرعي: ${fmt(s.sub)}`,
    ...(s.discount ? [`خصم ${Math.round(DISCOUNT.rate * 100)}%: - ${fmt(s.discount)}`] : []),
    `الشحن (${$("#coArea").value === "giza" ? "الجيزة" : "القاهرة"}): ${fmt(s.shipping)}`,
    `الإجمالي: ${fmt(s.total)}`,
    `طريقة العربون: ${selectedPayMethod() === "instapay" ? "إنستاباي" : "كاش / محفظة"}`,
    `رقم العملية: ${values.txnRef}`,
    `العربون المدفوع (30%): ${fmt(s.deposit)}`,
    `المتبقي عند الاستلام: ${fmt(s.remaining)}`
  ].join("\n");

  $("#orderText").value = text;
  track("generate_lead", { currency: "EGP", value: s.total, lead_source: selectedPayMethod() });
  $("#checkoutForm").hidden = true;
  $("#resultPanel").hidden = false;

  const wa = $("#waLink");
  if (WHATSAPP_NUMBER) {
    wa.href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
    wa.hidden = false;
  } else {
    wa.hidden = true;
  }
});

$("#copyOrder").onclick = async () => {
  const text = $("#orderText").value;
  try {
    await navigator.clipboard.writeText(text);
    showToast("تم نسخ تفاصيل الطلب");
  } catch {
    $("#orderText").select();
    showToast("انسخ النص يدوياً");
  }
};

/* =========================================================
   6) النوافذ والدرج والقائمة
   ========================================================= */
function lockScroll() { document.body.style.overflow = "hidden"; }
function unlockScrollIfIdle() {
  if (!$$(".overlay.open").length && !$("#cartDrawer").classList.contains("open")) {
    document.body.style.overflow = "";
  }
}
function openOverlay(sel) { $(sel).classList.add("open"); lockScroll(); }
function closeOverlay(sel) { $(sel).classList.remove("open"); unlockScrollIfIdle(); }
function openCart() {
  renderCart();
  $("#cartDrawer").classList.add("open");
  lockScroll();
}
function closeCart() {
  $("#cartDrawer").classList.remove("open");
  unlockScrollIfIdle();
}

$("#productGrid").addEventListener("click", e => {
  const b = e.target.closest("[data-open]");
  if (b) openProduct(b.dataset.open);
});
$("#filters").addEventListener("click", e => {
  const chip = e.target.closest("[data-filter]");
  if (!chip) return;
  activeFilter = chip.dataset.filter;
  renderFilters();
  renderProducts();
});
$("#cartBtn").onclick = openCart;
$("#bnCart").onclick = openCart;
$("#pvThumbs").addEventListener("click", e => {
  const t = e.target.closest(".pv-thumb");
  if (!t) return;
  $("#pvImg").src = t.dataset.src;
  $$(".pv-thumb").forEach(b => b.classList.toggle("on", b === t));
});

/* تبويبات نافذة المنتج */
function selectTab(id) {
  $$(".pv-tab").forEach(t => t.setAttribute("aria-selected", String(t.dataset.tab === id)));
  $("#tabDesc").hidden = id !== "tabDesc";
  $("#tabInfo").hidden = id !== "tabInfo";
}
$$(".pv-tab").forEach(t => t.addEventListener("click", () => selectTab(t.dataset.tab)));
$("#cartFoot").addEventListener("click", e => {
  if (e.target.closest("#checkoutBtn")) openCheckout();
  if (e.target.closest("[data-close-drawer]")) closeCart();
});
$("#cartDrawer").addEventListener("click", e => {
  if (e.target.closest("[data-close-drawer]")) closeCart();
});

$$(".overlay").forEach(o => {
  o.addEventListener("click", e => {
    if (e.target === o || e.target.closest("[data-close]")) closeOverlay("#" + o.id);
  });
});
document.addEventListener("keydown", e => {
  if (e.key !== "Escape") return;
  $$(".overlay.open").forEach(o => o.classList.remove("open"));
  closeCart();
  unlockScrollIfIdle();
});

$("#menuToggle").onclick = () => {
  const open = $("#navLinks").classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded", String(open));
};
$$("#navLinks a").forEach(a => a.addEventListener("click", () => {
  $("#navLinks").classList.remove("open");
  $("#menuToggle").setAttribute("aria-expanded", "false");
}));

/* شاشة التحميل */
function hideLoader() {
  setTimeout(() => $("#loader").classList.add("hide"), 1400);
}
if (document.readyState === "complete") hideLoader();
else window.addEventListener("load", hideLoader);
setTimeout(() => $("#loader").classList.add("hide"), 4000); // احتياطي

/* ---------- البحث ---------- */
function setSearchOpen(open) {
  $("#searchBar").hidden = !open;
  $("#searchBtn").setAttribute("aria-expanded", String(open));
  if (open) $("#searchInput").focus();
  else { $("#searchInput").value = ""; searchQuery = ""; renderProducts(); }
}
$("#searchBtn").onclick = () => setSearchOpen($("#searchBar").hidden);
$("#searchClose").onclick = () => setSearchOpen(false);
$("#searchInput").addEventListener("input", e => {
  searchQuery = e.target.value;
  renderProducts();
});
document.addEventListener("keydown", e => {
  if (e.key === "/" && document.activeElement.tagName !== "INPUT") {
    e.preventDefault();
    setSearchOpen(true);
  }
});

/* ---------- زر الرجوع لأعلى ---------- */
window.addEventListener("scroll", () => {
  $("#toTop").classList.toggle("show", window.scrollY > 700);
}, { passive: true });
$("#toTop").onclick = () => window.scrollTo({ top: 0, behavior: "smooth" });

/* ---------- حبات البن المتساقطة في الهيرو ---------- */
(function makeBeans() {
  const box = $(".beans");
  if (!box || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const count = window.innerWidth < 760 ? 16 : 36;
  for (let i = 0; i < count; i++) {
    const b = document.createElement("span");
    b.className = "bean";
    const w = 13 + Math.random() * 12;
    b.style.width = `${w}px`;
    b.style.left = `${Math.random() * 100}%`;
    b.style.opacity = `${0.55 + Math.random() * 0.4}`;
    b.style.animationDuration = `${14 + Math.random() * 14}s`;
    b.style.animationDelay = `${-Math.random() * 25}s`;
    box.appendChild(b);
  }
})();

/* ---------- سلايدر الهيرو ---------- */
const heroSlides = $$(".slide");
const heroEl = $("#home");
let slideIdx = 0;
let slideTimer = null;

function showSlide(i) {
  slideIdx = (i + heroSlides.length) % heroSlides.length;
  heroSlides.forEach((s, k) => {
    s.classList.toggle("active", k === slideIdx);
    s.setAttribute("aria-hidden", String(k !== slideIdx));
  });
  $$(".dot").forEach((d, k) => d.setAttribute("aria-current", String(k === slideIdx)));
}
function startSlider() {
  clearInterval(slideTimer);
  slideTimer = setInterval(() => showSlide(slideIdx + 1), 6500);
}
$("#slideNext").onclick = () => { showSlide(slideIdx + 1); startSlider(); };
$("#slidePrev").onclick = () => { showSlide(slideIdx - 1); startSlider(); };
$$(".dot").forEach((d, k) => d.onclick = () => { showSlide(k); startSlider(); });
heroEl.addEventListener("mouseenter", () => clearInterval(slideTimer));
heroEl.addEventListener("mouseleave", startSlider);
heroEl.addEventListener("focusin", () => clearInterval(slideTimer));
heroEl.addEventListener("focusout", startSlider);
startSlider();

/* ---------- التشغيل ---------- */
async function init() {
  await loadData();
  if (OFFERS[0]) $("#slideOfferPrice").textContent = fmt(OFFERS[0].price);
  cart = loadCart();
  saveCart();
  renderOffers();
  injectProductSchema();
  renderFilters();
  renderProducts();
  renderCart();
  observeReveal();
}
init();
