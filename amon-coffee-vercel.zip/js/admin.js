/* =========================================================
   لوحة تحكم أمون
   ملاحظة أمان: الباسورد بيتفحص في المتصفح، ده بيمنع الدخول العادي
   بس مش حماية كاملة لأن أي حد يقدر يشوف الكود. للحماية الكاملة
   لازم سيرفر أو خدمة قاعدة بيانات.
   ========================================================= */

// SHA-256 للباسورد. الباسورد الحالي: Amon@2026  (غيّره بعد أول دخول)
const ADMIN_HASH = "fb1fd3633f778eb5fb65339b6a7090fb446825717df04c000f2f19dcab859d74";
const DATA_URL = "data/products.json";
const SIZES = [250, 500, 1000];
const SIZE_LABEL = { 250: "250 جرام", 500: "500 جرام", 1000: "1 كيلو" };
const ROAST_OPTS = [["light","فاتح"],["medium","وسط"],["dark","غامق"],["special","مميز"]];
const STYLE_OPTS = [["plain","ساده"],["spiced","محوج"],["special","مميز"]];

let state = { products: [], extra: {} };
let dirty = false;

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove("show"), 2400);
}

function setDirty(v) {
  dirty = v;
  const st = $("#statusText");
  st.classList.toggle("dirty", v);
  if (v) st.textContent = "فيه تعديلات مش محفوظة لحد ما تحمّل الملف";
  else if (!st.dataset.loaded) st.textContent = "";
}

function options(list, selected) {
  return list.map(([v, l]) => `<option value="${v}" ${v === selected ? "selected" : ""}>${l}</option>`).join("");
}

/* ---------- الدخول ---------- */
async function sha256Hex(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}

$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const err = $("#loginError");
  err.textContent = "";
  if (!window.crypto?.subtle) {
    err.textContent = "افتح اللوحة عن طريق http://localhost:8000/admin.html";
    return;
  }
  const hash = await sha256Hex($("#adminPass").value);
  if (hash === ADMIN_HASH) {
    sessionStorage.setItem("amon-admin", "1");
    showAdmin();
  } else {
    err.textContent = "الباسورد غلط، حاول تاني";
  }
});

$("#logoutBtn").onclick = () => {
  if (dirty && !confirm("فيه تعديلات مش محفوظة، متأكد إنك عايز تخرج؟")) return;
  sessionStorage.removeItem("amon-admin");
  location.reload();
};

function showAdmin() {
  $("#loginView").hidden = true;
  $("#adminView").hidden = false;
  $("#topActions").hidden = false;
  loadData();
}

/* ---------- تحميل وعرض المنتجات ---------- */
async function loadData() {
  const st = $("#statusText");
  try {
    const res = await fetch(DATA_URL, { cache: "no-store" });
    if (!res.ok) throw new Error();
    const data = await res.json();
    state.products = (data.products || []).map(normalize);
    state.extra = { offers: data.offers || [], discount: data.discount || null };
    st.dataset.loaded = "1";
    st.textContent = `${state.products.length} منتجات`;
    render();
  } catch {
    st.textContent = "مش قادر أقرأ data/products.json. تأكد إنك شغّال على localhost";
  }
}

function normalize(p) {
  return {
    ...p,
    desc: p.desc || "",
    image: p.image || `assets/products/${p.id}.png`,
    roast: p.roast || "light",
    style: p.style || "plain",
    prices: Object.fromEntries(SIZES.map(g => [g, Number(p.prices?.[g]) || 0])),
    stock: Object.fromEntries(SIZES.map(g => [g, Math.max(0, Math.floor(Number(p.stock?.[g]) || 0))]))
  };
}

function render() {
  $("#productsEditor").innerHTML = state.products.map((p, i) => `
    <article class="a-card" data-i="${i}">
      <div class="a-head">
        <div class="a-thumb"><img src="${p.image}" alt="" onerror="this.style.display='none'"></div>
        <div class="a-title"><b>${p.name}</b><small>${p.id}</small></div>
        <button class="btn-danger" type="button" data-del="${i}">حذف</button>
      </div>
      <div class="a-grid">
        <div class="field"><label>الاسم</label><input data-field="name" value="${p.name}"></div>
        <div class="field"><label>ملف الصورة</label><input data-field="image" value="${p.image}"></div>
        <div class="field"><label>التحميص</label><select data-field="roast">${options(ROAST_OPTS, p.roast)}</select></div>
        <div class="field"><label>النوع</label><select data-field="style">${options(STYLE_OPTS, p.style)}</select></div>
        <div class="field" style="grid-column:1/-1"><label>الوصف</label><textarea data-field="desc" rows="2">${p.desc}</textarea></div>
      </div>
      <table class="a-table">
        <thead><tr><th>الحجم</th><th>السعر (ج.م)</th><th>الكمية المتاحة</th></tr></thead>
        <tbody>
          ${SIZES.map(g => `
            <tr>
              <td>${SIZE_LABEL[g]}</td>
              <td><input type="number" min="0" data-price="${g}" value="${p.prices[g]}"></td>
              <td><input type="number" min="0" data-stock="${g}" value="${p.stock[g]}"></td>
            </tr>`).join("")}
        </tbody>
      </table>
    </article>`).join("") || `<p class="admin-note">مفيش منتجات. اضغط "منتج جديد".</p>`;
}

/* تعديل الحقول: بيتحدّث في الذاكرة فوراً */
$("#productsEditor").addEventListener("input", e => {
  const card = e.target.closest("[data-i]");
  if (!card) return;
  const p = state.products[Number(card.dataset.i)];
  const el = e.target;

  if (el.dataset.field) p[el.dataset.field] = el.value;
  else if (el.dataset.price) p.prices[el.dataset.price] = Math.max(0, Number(el.value) || 0);
  else if (el.dataset.stock) p.stock[el.dataset.stock] = Math.max(0, Math.floor(Number(el.value) || 0));
  else return;
  setDirty(true);
});

$("#productsEditor").addEventListener("change", e => {
  if (e.target.dataset.field) render(); // يحدّث العنوان والصورة
});

$("#productsEditor").addEventListener("click", e => {
  const del = e.target.closest("[data-del]");
  if (!del) return;
  const p = state.products[Number(del.dataset.del)];
  if (!confirm(`متأكد إنك عايز تحذف "${p.name}"؟`)) return;
  state.products.splice(Number(del.dataset.del), 1);
  setDirty(true);
  render();
});

/* ---------- منتج جديد ---------- */
$("#addNewBtn").onclick = () => {
  $("#newPanel").hidden = false;
  $("#newPanel").scrollIntoView({ behavior: "smooth", block: "start" });
};
$("#cancelNew").onclick = () => {
  $("#newPanel").hidden = true;
  $("#newPanel").reset();
  $("#newError").textContent = "";
};

$("#newPanel").addEventListener("submit", e => {
  e.preventDefault();
  const f = e.currentTarget;
  const err = $("#newError");
  const id = f.id.value.trim().toLowerCase();
  const name = f.name.value.trim();

  if (!/^[a-z0-9-]+$/.test(id)) return err.textContent = "المعرّف لازم يكون إنجليزي صغير وأرقام وشرطة بس";
  if (state.products.some(p => p.id === id)) return err.textContent = "المعرّف ده موجود قبل كده";
  if (!name) return err.textContent = "اكتب اسم المنتج";

  const prices = Object.fromEntries(SIZES.map(g => [g, Math.max(0, Number(f[`p${g}`].value) || 0)]));
  if (SIZES.some(g => prices[g] <= 0)) return err.textContent = "اكتب سعر لكل حجم";
  const stock = Object.fromEntries(SIZES.map(g => [g, Math.max(0, Math.floor(Number(f[`s${g}`].value) || 0))]));

  state.products.push({
    id, name,
    image: f.image.value.trim() || `assets/products/${id}.png`,
    desc: f.desc.value.trim(),
    roast: f.roast.value,
    style: f.style.value,
    prices, stock
  });
  setDirty(true);
  f.reset();
  f.hidden = true;
  err.textContent = "";
  render();
  toast("تمت إضافة المنتج");
});

/* ---------- حفظ وتحميل الملف ---------- */
$("#downloadBtn").onclick = () => {
  const bad = state.products.find(p => SIZES.some(g => p.prices[g] <= 0));
  if (bad && !confirm(`"${bad.name}" فيه حجم سعره صفر، ده هيتخفى من الموقع. تكمل؟`)) return;

  const blob = new Blob([JSON.stringify({ products: state.products, ...state.extra }, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "products.json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(a.href);
  setDirty(false);
  toast("تم التحميل. ارفع الملف على data/products.json");
};

window.addEventListener("beforeunload", e => {
  if (dirty) { e.preventDefault(); e.returnValue = ""; }
});

/* ---------- بداية ---------- */
if (sessionStorage.getItem("amon-admin") === "1") showAdmin();
